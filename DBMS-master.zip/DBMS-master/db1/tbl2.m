id::y::n::y::y::n::n::int
sal::n::n::y::n::5000::gt:500::int
