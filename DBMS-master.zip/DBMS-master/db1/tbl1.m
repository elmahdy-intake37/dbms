id::y::n::y::y::n::::n
sal::n::n::n::n::n::::n
